import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()

    if (!token) {
      return NextResponse.json({ error: "Reward token required" }, { status: 400 })
    }

    // Verify reward token
    let decoded
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET!) as any
    } catch (error) {
      return NextResponse.json({ error: "Invalid or expired reward token" }, { status: 401 })
    }

    // Check if reward link exists and is not claimed
    const { data: rewardLink, error: linkError } = await supabase
      .from("reward_links")
      .select("*")
      .eq("reward_token", token)
      .eq("is_claimed", false)
      .single()

    if (linkError || !rewardLink) {
      return NextResponse.json({ error: "Reward already claimed or invalid" }, { status: 400 })
    }

    // Get user data
    const { data: user, error: userError } = await supabase.from("users").select("*").eq("id", decoded.userId).single()

    if (userError || !user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    const rewardAmount = 250 // 500 extra requests

    // Update user's request limit
    const newLimit = user.requests_limit + rewardAmount

    const { error: updateError } = await supabase
      .from("users")
      .update({
        requests_limit: newLimit,
        total_requests: (user.total_requests || 0) + rewardAmount,
      })
      .eq("id", user.id)

    if (updateError) {
      return NextResponse.json({ error: "Failed to update user limits" }, { status: 500 })
    }

    // Mark reward as claimed
    await supabase
      .from("reward_links")
      .update({
        is_claimed: true,
        claimed_at: new Date().toISOString(),
      })
      .eq("id", rewardLink.id)

    // Log the reward claim
    await supabase.from("user_analytics").insert({
      user_id: user.id,
      endpoint: "/api/claim-reward",
      method: "POST",
      status_code: 200,
      response_time_ms: 100,
    })

    return NextResponse.json({
      success: true,
      message: "Reward claimed successfully!",
      rewardAmount,
      newLimit,
    })
  } catch (error) {
    console.error("Claim reward error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
