import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const TMDB_API_KEY = "c0d0e0e40bae98909390cde31c402a9b"

async function validateApiToken(token: string) {
  try {
    const { data: user, error } = await supabase.from("users").select("*").eq("api_token", token).single()
    if (error || !user) return null

    await supabase.rpc("check_and_reset_user_requests", { user_id: user.id })
    const { data: updatedUser } = await supabase.from("users").select("*").eq("id", user.id).single()
    return updatedUser || user
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "API token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const user = await validateApiToken(token)

    if (!user) {
      return NextResponse.json({ error: "Invalid API token" }, { status: 401 })
    }

    const urlParams = new URL(request.url)
    const titulo = urlParams.searchParams.get("titulo")
    const tipo = urlParams.searchParams.get("tipo") // filme ou serie

    if (!titulo || !tipo) {
      return NextResponse.json(
        {
          error: "Missing parameters",
          message: "Required parameters: titulo and tipo",
        },
        { status: 400 },
      )
    }

    const dailyLimit = user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999
    if (user.daily_requests_used >= dailyLimit) {
      return NextResponse.json(
        {
          error: "Daily request limit exceeded",
          message: `Your ${user.plan} plan allows ${dailyLimit} requests per day`,
        },
        { status: 429 },
      )
    }

    // Search on TMDB
    const searchType = tipo === "filme" ? "movie" : "tv"
    const searchUrl = `https://api.themoviedb.org/3/search/${searchType}`
    const searchParams = new URLSearchParams({
      api_key: TMDB_API_KEY,
      query: titulo,
      language: "pt-BR",
    })

    const searchResponse = await fetch(`${searchUrl}?${searchParams}`)
    const searchData = await searchResponse.json()

    if (!searchData.results || searchData.results.length === 0) {
      return NextResponse.json(
        {
          error: "Content not found",
          message: "Title not found in TMDB database",
        },
        { status: 404 },
      )
    }

    const item = searchData.results[0]
    const tmdbId = item.id

    // Get details
    const detailsUrl = `https://api.themoviedb.org/3/${searchType}/${tmdbId}`
    const detailsParams = new URLSearchParams({
      api_key: TMDB_API_KEY,
      language: "pt-BR",
    })

    const detailsResponse = await fetch(`${detailsUrl}?${detailsParams}`)
    const detailsData = await detailsResponse.json()

    // Get credits
    const creditsUrl = `https://api.themoviedb.org/3/${searchType}/${tmdbId}/credits`
    const creditsParams = new URLSearchParams({
      api_key: TMDB_API_KEY,
      language: "pt-BR",
    })

    const creditsResponse = await fetch(`${creditsUrl}?${creditsParams}`)
    const creditsData = await creditsResponse.json()

    // Get videos
    const videosUrl = `https://api.themoviedb.org/3/${searchType}/${tmdbId}/videos`
    const videosParams = new URLSearchParams({
      api_key: TMDB_API_KEY,
    })

    const videosResponse = await fetch(`${videosUrl}?${videosParams}`)
    const videosData = await videosResponse.json()

    const elenco = creditsData.cast?.slice(0, 10).map((actor: any) => actor.name) || []
    const diretores =
      creditsData.crew?.filter((person: any) => person.job === "Director").map((director: any) => director.name) || []
    const criadores = detailsData.created_by?.map((creator: any) => creator.name) || []

    const trailer = videosData.results?.find((video: any) => video.type === "Trailer" && video.site === "YouTube")
    const trailerUrl = trailer ? `https://www.youtube.com/watch?v=${trailer.key}` : null

    const result = {
      titulo: detailsData.title || detailsData.name,
      titulo_original: detailsData.original_title || detailsData.original_name,
      descricao: detailsData.overview,
      ano: (detailsData.release_date || detailsData.first_air_date || "").substring(0, 4),
      generos: detailsData.genres?.map((genre: any) => genre.name) || [],
      duracao: detailsData.runtime,
      temporadas: detailsData.number_of_seasons,
      episodios: detailsData.number_of_episodes,
      nota: detailsData.vote_average,
      votos: detailsData.vote_count,
      idiomas: detailsData.spoken_languages,
      poster: detailsData.poster_path ? `https://image.tmdb.org/t/p/w500${detailsData.poster_path}` : null,
      banner: detailsData.backdrop_path ? `https://image.tmdb.org/t/p/original${detailsData.backdrop_path}` : null,
      elenco,
      diretores,
      criadores,
      trailer_youtube: trailerUrl,
    }

    await supabase
      .from("users")
      .update({ daily_requests_used: user.daily_requests_used + 1 })
      .eq("id", user.id)

    return NextResponse.json({
      success: true,
      data: result,
      user_info: {
        requests_used_today: user.daily_requests_used + 1,
        daily_limit: dailyLimit,
        plan: user.plan,
      },
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        message: "Failed to fetch content details",
      },
      { status: 500 },
    )
  }
}
