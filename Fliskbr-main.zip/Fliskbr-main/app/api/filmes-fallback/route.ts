import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Mock data em caso de falha da API
const MOCK_MOVIES = [
  {
    stream_id: "12345",
    name: "Inception",
    release_year: "2010",
    cover: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg",
  },
  {
    stream_id: "67890",
    name: "The Matrix",
    release_year: "1999",
    cover: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg",
  },
  {
    stream_id: "11111",
    name: "Interstellar",
    release_year: "2014",
    cover: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
  },
  {
    stream_id: "22222",
    name: "The Dark Knight",
    release_year: "2008",
    cover: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
  },
  {
    stream_id: "33333",
    name: "Pulp Fiction",
    release_year: "1994",
    cover: "https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg",
  },
]

const XTREAM_CONFIG = {
  USERNAME: "98413537",
  PASSWORD: "65704277",
  BASE_URL: "https://finstv.wtf/player_api.php",
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w-]+/g, "-")
}

function generateSlug(title: string, mediaId: string): string {
  const crypto = require("crypto")
  const hash = crypto.createHash("md5").update(mediaId).digest("hex").substring(0, 6)
  return `${slugify(title)}-${hash}`
}

async function validateApiToken(token: string) {
  try {
    const { data: user, error } = await supabase.from("users").select("*").eq("api_token", token).single()
    if (error || !user) return null

    await supabase.rpc("check_and_reset_user_requests", { user_id: user.id })
    const { data: updatedUser } = await supabase.from("users").select("*").eq("id", user.id).single()
    return updatedUser || user
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "API token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const user = await validateApiToken(token)

    if (!user) {
      return NextResponse.json({ error: "Invalid API token" }, { status: 401 })
    }

    const dailyLimit = user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999
    if (user.daily_requests_used >= dailyLimit) {
      return NextResponse.json(
        {
          error: "Daily request limit exceeded",
          message: `Your ${user.plan} plan allows ${dailyLimit} requests per day`,
        },
        { status: 429 },
      )
    }

    const dominio = request.nextUrl.origin

    // Try Xtream API first, fallback to mock data
    let movies = []
    let dataSource = "mock"

    try {
      const xtreamUrl = `${XTREAM_CONFIG.BASE_URL}?username=${XTREAM_CONFIG.USERNAME}&password=${XTREAM_CONFIG.PASSWORD}&action=get_vod_streams`
      const response = await fetch(xtreamUrl, {
        method: "GET",
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        },
        signal: AbortSignal.timeout(5000), // 5 second timeout
      })

      if (response.ok) {
        const data = await response.json()
        const moviesArray = Array.isArray(data) ? data : data.results || data.data || []

        if (moviesArray && moviesArray.length > 0) {
          movies = moviesArray.slice(0, 20).map((item: any) => ({
            id: item.stream_id || item.id,
            titulo: item.name || item.title,
            ano: item.release_year || item.year,
            capa: item.cover || item.poster,
            player: `${dominio}/api/player/${generateSlug(item.name || item.title, item.stream_id || item.id)}.mp4?id=${item.stream_id || item.id}&type=movie`,
            detalhes: `${dominio}/api/detalhes?titulo=${encodeURIComponent(item.name || item.title)}&tipo=filme`,
          }))
          dataSource = "xtream"
        }
      }
    } catch (error) {
      console.log("Xtream API failed, using mock data:", error.message)
    }

    // Use mock data if Xtream failed
    if (movies.length === 0) {
      movies = MOCK_MOVIES.map((item) => ({
        id: item.stream_id,
        titulo: item.name,
        ano: item.release_year,
        capa: item.cover,
        player: `${dominio}/api/player/${generateSlug(item.name, item.stream_id)}.mp4?id=${item.stream_id}&type=movie`,
        detalhes: `${dominio}/api/detalhes?titulo=${encodeURIComponent(item.name)}&tipo=filme`,
      }))
    }

    // Increment request count
    await supabase
      .from("users")
      .update({ daily_requests_used: user.daily_requests_used + 1 })
      .eq("id", user.id)

    return NextResponse.json({
      success: true,
      data: movies,
      dataSource,
      pagination: {
        total: movies.length,
        page: 1,
        per_page: movies.length,
      },
      user_info: {
        requests_used_today: user.daily_requests_used + 1,
        daily_limit: dailyLimit,
        plan: user.plan,
      },
    })
  } catch (error) {
    console.error("API error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        message: error.message,
      },
      { status: 500 },
    )
  }
}
