import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

// Xtream API Configuration
const XTREAM_CONFIG = {
  USERNAME: "98413537",
  PASSWORD: "65704277",
  BASE_URL: "https://finstv.wtf/player_api.php",
}

// Mock data para fallback (mais filmes)
const MOCK_MOVIES = [
  {
    stream_id: "12345",
    name: "Inception",
    release_year: "2010",
    cover: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg",
  },
  {
    stream_id: "67890",
    name: "The Matrix",
    release_year: "1999",
    cover: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg",
  },
  {
    stream_id: "11111",
    name: "Interstellar",
    release_year: "2014",
    cover: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg",
  },
  {
    stream_id: "22222",
    name: "The Dark Knight",
    release_year: "2008",
    cover: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg",
  },
  {
    stream_id: "33333",
    name: "Pulp Fiction",
    release_year: "1994",
    cover: "https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg",
  },
  {
    stream_id: "44444",
    name: "The Shawshank Redemption",
    release_year: "1994",
    cover: "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg",
  },
  {
    stream_id: "55555",
    name: "Forrest Gump",
    release_year: "1994",
    cover: "https://image.tmdb.org/t/p/w500/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg",
  },
  {
    stream_id: "66666",
    name: "The Godfather",
    release_year: "1972",
    cover: "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg",
  },
  {
    stream_id: "77777",
    name: "Titanic",
    release_year: "1997",
    cover: "https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg",
  },
  {
    stream_id: "88888",
    name: "Avatar",
    release_year: "2009",
    cover: "https://image.tmdb.org/t/p/w500/6EiRUJpuoeQPghrs3YNktfnqOVh.jpg",
  },
  {
    stream_id: "99999",
    name: "Avengers: Endgame",
    release_year: "2019",
    cover: "https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg",
  },
  {
    stream_id: "10101",
    name: "Spider-Man: No Way Home",
    release_year: "2021",
    cover: "https://image.tmdb.org/t/p/w500/1g0dhYtq4irTY1GPXvft6k4YLjm.jpg",
  },
  {
    stream_id: "20202",
    name: "Top Gun: Maverick",
    release_year: "2022",
    cover: "https://image.tmdb.org/t/p/w500/62HCnUTziyWcpDaBO2i1DX17ljH.jpg",
  },
  {
    stream_id: "30303",
    name: "Black Panther",
    release_year: "2018",
    cover: "https://image.tmdb.org/t/p/w500/uxzzxijgPIY7slzFvMotPv8wjKA.jpg",
  },
  {
    stream_id: "40404",
    name: "Joker",
    release_year: "2019",
    cover: "https://image.tmdb.org/t/p/w500/udDclJoHjfjb8Ekgsd4FDteOkCU.jpg",
  },
  {
    stream_id: "50505",
    name: "Dune",
    release_year: "2021",
    cover: "https://image.tmdb.org/t/p/w500/d5NXSklXo0qyIYkgV94XAgMIckC.jpg",
  },
  {
    stream_id: "60606",
    name: "No Time to Die",
    release_year: "2021",
    cover: "https://image.tmdb.org/t/p/w500/iUgygt3fscRoKWCV1d0C7FbM9TP.jpg",
  },
  {
    stream_id: "70707",
    name: "Fast & Furious 9",
    release_year: "2021",
    cover: "https://image.tmdb.org/t/p/w500/bOFaAXmWWXC3Rbv4u4uM9ZSzRXP.jpg",
  },
  {
    stream_id: "80808",
    name: "Wonder Woman 1984",
    release_year: "2020",
    cover: "https://image.tmdb.org/t/p/w500/8UlWHLMpgZm9bx6QYh0NFoq67TZ.jpg",
  },
  {
    stream_id: "90909",
    name: "Tenet",
    release_year: "2020",
    cover: "https://image.tmdb.org/t/p/w500/k68nPLbIST6NP96JmTxmZijEvCA.jpg",
  },
  // Adicionar mais 80 filmes para chegar a 100
  ...Array.from({ length: 80 }, (_, i) => ({
    stream_id: `${100000 + i}`,
    name: `Movie ${i + 21}`,
    release_year: `${2000 + (i % 24)}`,
    cover: `https://picsum.photos/500/750?random=${i + 21}`,
  })),
]

// Rate limiting store
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w-]+/g, "-")
    .replace(/^-+|-+$/g, "")
}

function generateSlug(title: string, mediaId: string): string {
  const crypto = require("crypto")
  const hash = crypto.createHash("md5").update(mediaId.toString()).digest("hex").substring(0, 6)
  return `${slugify(title)}-${hash}`
}

async function checkRateLimit(userId: string, limit: number): Promise<boolean> {
  const now = Date.now()
  const windowMs = 60 * 1000 // 1 minute

  const userLimit = rateLimitStore.get(userId)

  if (!userLimit || now > userLimit.resetTime) {
    rateLimitStore.set(userId, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (userLimit.count >= limit) {
    return false
  }

  userLimit.count++
  return true
}

async function validateApiToken(token: string) {
  try {
    const { data: user, error } = await supabase.from("users").select("*").eq("api_token", token).single()

    if (error || !user) {
      return null
    }

    // Check and reset daily requests if needed
    await supabase.rpc("check_and_reset_user_requests", { user_id: user.id })

    // Get updated user data
    const { data: updatedUser } = await supabase.from("users").select("*").eq("id", user.id).single()

    return updatedUser || user
  } catch (error) {
    console.error("Token validation error:", error)
    return null
  }
}

async function logApiUsage(
  userId: string,
  endpoint: string,
  statusCode: number,
  responseTime: number,
  request: NextRequest,
) {
  try {
    const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "127.0.0.1"
    const userAgent = request.headers.get("user-agent") || "Unknown"

    await supabase.rpc("log_api_usage", {
      p_user_id: userId,
      p_endpoint: endpoint,
      p_method: "GET",
      p_status_code: statusCode,
      p_response_time_ms: responseTime,
      p_ip_address: ip,
      p_user_agent: userAgent,
    })
  } catch (error) {
    console.error("Failed to log API usage:", error)
  }
}

async function fetchFromXtream(limit = 200): Promise<any[]> {
  try {
    const url = `${XTREAM_CONFIG.BASE_URL}?username=${XTREAM_CONFIG.USERNAME}&password=${XTREAM_CONFIG.PASSWORD}&action=get_vod_streams`

    console.log("Fetching from Xtream:", url)

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
        Accept: "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
      },
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    const text = await response.text()
    let data
    try {
      data = JSON.parse(text)
    } catch (parseError) {
      throw new Error("Invalid JSON response from Xtream API")
    }

    // Handle different response formats
    if (Array.isArray(data)) {
      return data.slice(0, limit)
    } else if (data && typeof data === "object") {
      const results = data.results || data.data || data.streams || data.movies || []
      return Array.isArray(results) ? results.slice(0, limit) : []
    }

    return []
  } catch (error) {
    console.error("Xtream API error:", error)
    throw error
  }
}

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "API token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const user = await validateApiToken(token)

    if (!user) {
      return NextResponse.json({ error: "Invalid API token" }, { status: 401 })
    }

    // Check rate limit
    const canProceed = await checkRateLimit(user.id, user.rate_limit)
    if (!canProceed) {
      const responseTime = Date.now() - startTime
      await logApiUsage(user.id, "/api/filmes", 429, responseTime, request)

      return NextResponse.json(
        {
          error: "Rate limit exceeded",
          message: `You can make ${user.rate_limit} requests per minute`,
        },
        { status: 429 },
      )
    }

    // Check daily request limit
    const dailyLimit = user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999
    if (user.daily_requests_used >= dailyLimit) {
      const responseTime = Date.now() - startTime
      await logApiUsage(user.id, "/api/filmes", 429, responseTime, request)

      return NextResponse.json(
        {
          error: "Daily request limit exceeded",
          message: `Your ${user.plan} plan allows ${dailyLimit} requests per day`,
        },
        { status: 429 },
      )
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const limit = Math.min(Number.parseInt(searchParams.get("limit") || "100"), 500) // Max 500 filmes
    const page = Math.max(Number.parseInt(searchParams.get("page") || "1"), 1)
    const category = searchParams.get("category")

    const dominio = request.nextUrl.origin
    let movies = []
    let dataSource = "mock"
    let errorMessage = null

    // Try to fetch from Xtream API
    try {
      const xtreamData = await fetchFromXtream(limit * 2) // Fetch more to have variety

      if (xtreamData && xtreamData.length > 0) {
        // Apply pagination
        const startIndex = (page - 1) * limit
        const endIndex = startIndex + limit

        movies = xtreamData.slice(startIndex, endIndex).map((item: any) => ({
          id: item.stream_id || item.id || Math.random().toString(36).substr(2, 9),
          titulo: item.name || item.title || "Título não disponível",
          ano: item.release_year || item.year || "N/A",
          capa: item.cover || item.poster || "https://via.placeholder.com/500x750?text=No+Image",
          categoria: item.category_name || "Geral",
          player: `${dominio}/api/player/${generateSlug(item.name || item.title || "movie", item.stream_id || item.id || "0")}.mp4?id=${item.stream_id || item.id}&type=movie`,
          detalhes: `${dominio}/api/detalhes?titulo=${encodeURIComponent(item.name || item.title || "")}&tipo=filme`,
        }))
        dataSource = "xtream"
      }
    } catch (error) {
      console.error("Failed to fetch from Xtream, using mock data:", error)
      errorMessage = error.message
    }

    // Use mock data if Xtream failed or returned no data
    if (movies.length === 0) {
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + limit

      movies = MOCK_MOVIES.slice(startIndex, endIndex).map((item) => ({
        id: item.stream_id,
        titulo: item.name,
        ano: item.release_year,
        capa: item.cover,
        categoria: "Geral",
        player: `${dominio}/api/player/${generateSlug(item.name, item.stream_id)}.mp4?id=${item.stream_id}&type=movie`,
        detalhes: `${dominio}/api/detalhes?titulo=${encodeURIComponent(item.name)}&tipo=filme`,
      }))
      dataSource = "mock"
    }

    // Increment daily request count
    await supabase
      .from("users")
      .update({ daily_requests_used: user.daily_requests_used + 1 })
      .eq("id", user.id)

    const responseTime = Date.now() - startTime
    await logApiUsage(user.id, "/api/filmes", 200, responseTime, request)

    const totalMovies = dataSource === "mock" ? MOCK_MOVIES.length : 1000 // Estimate for Xtream
    const totalPages = Math.ceil(totalMovies / limit)

    return NextResponse.json({
      success: true,
      data: movies,
      meta: {
        dataSource,
        total: totalMovies,
        page,
        per_page: limit,
        total_pages: totalPages,
        has_next: page < totalPages,
        has_prev: page > 1,
        xtreamError: errorMessage,
        response_time_ms: responseTime,
      },
      user_info: {
        requests_used_today: user.daily_requests_used + 1,
        daily_limit: dailyLimit,
        plan: user.plan,
      },
    })
  } catch (error) {
    const responseTime = Date.now() - startTime
    console.error("API error:", error)

    return NextResponse.json(
      {
        error: "Internal server error",
        message: error.message || "Failed to fetch movies from streaming service",
        details: process.env.NODE_ENV === "development" ? error.stack : undefined,
      },
      { status: 500 },
    )
  }
}
