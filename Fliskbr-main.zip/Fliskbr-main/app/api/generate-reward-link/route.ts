import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const LINKMONETIZADO_CONFIG = {
  API_TOKEN: "9062a52898e82e04794e34176e5ef2c4baec79c3",
  API_URL: "https://linkmonetizado.com/api",
}

function generateRandomAlias(): string {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let result = ""
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return `flisk_${result}`
}

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Authorization token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    // Get user data
    const { data: user, error } = await supabase.from("users").select("*").eq("id", decoded.userId).single()

    if (error || !user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Check if user already generated a link today
    const today = new Date().toISOString().split("T")[0]
    const { data: existingLink } = await supabase
      .from("reward_links")
      .select("*")
      .eq("user_id", user.id)
      .eq("created_date", today)
      .single()

    if (existingLink) {
      return NextResponse.json({
        success: true,
        shortenedUrl: existingLink.shortened_url,
        message: "You already generated a reward link today!",
        alreadyGenerated: true,
      })
    }

    // Generate reward link
    const rewardToken = jwt.sign({ userId: user.id, timestamp: Date.now() }, process.env.JWT_SECRET!, {
      expiresIn: "24h",
    })

    const destinationUrl = `${request.nextUrl.origin}/reward?token=${rewardToken}`
    const customAlias = generateRandomAlias()

    // Call LinkMonetizado API
    const apiUrl = `${LINKMONETIZADO_CONFIG.API_URL}?api=${LINKMONETIZADO_CONFIG.API_TOKEN}&url=${encodeURIComponent(destinationUrl)}&alias=${customAlias}`

    const response = await fetch(apiUrl)
    const result = await response.json()

    if (result.status === "error") {
      return NextResponse.json(
        {
          error: "Failed to generate monetized link",
          message: result.message,
        },
        { status: 500 },
      )
    }

    // Save link to database
    await supabase.from("reward_links").insert({
      user_id: user.id,
      reward_token: rewardToken,
      shortened_url: result.shortenedUrl,
      destination_url: destinationUrl,
      alias: customAlias,
      created_date: today,
      is_claimed: false,
    })

    return NextResponse.json({
      success: true,
      shortenedUrl: result.shortenedUrl,
      message: "Reward link generated successfully! Share this link to earn extra requests.",
    })
  } catch (error) {
    console.error("Generate reward link error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
