import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const XTREAM_CONFIG = {
  USERNAME: "98413537",
  PASSWORD: "65704277",
}

async function validateApiToken(token: string) {
  try {
    const { data: user, error } = await supabase.from("users").select("*").eq("api_token", token).single()
    if (error || !user) return null

    await supabase.rpc("check_and_reset_user_requests", { user_id: user.id })
    const { data: updatedUser } = await supabase.from("users").select("*").eq("id", user.id).single()
    return updatedUser || user
  } catch (error) {
    return null
  }
}

export async function GET(request: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "API token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const user = await validateApiToken(token)

    if (!user) {
      return NextResponse.json({ error: "Invalid API token" }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const mediaId = searchParams.get("id")
    const mediaType = searchParams.get("type")

    if (!mediaId || !mediaType || !["movie", "series"].includes(mediaType)) {
      return NextResponse.json(
        {
          error: "Invalid parameters",
          message: "Required parameters: id and type (movie or series)",
        },
        { status: 400 },
      )
    }

    const dailyLimit = user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999
    if (user.daily_requests_used >= dailyLimit) {
      return NextResponse.json(
        {
          error: "Daily request limit exceeded",
          message: `Your ${user.plan} plan allows ${dailyLimit} requests per day`,
        },
        { status: 429 },
      )
    }

    // Increment request count
    await supabase
      .from("users")
      .update({ daily_requests_used: user.daily_requests_used + 1 })
      .eq("id", user.id)

    // Redirect to streaming URL
    const streamingUrl = `https://finstv.wtf/${mediaType}/${XTREAM_CONFIG.USERNAME}/${XTREAM_CONFIG.PASSWORD}/${mediaId}.mp4`

    return NextResponse.redirect(streamingUrl)
  } catch (error) {
    console.error("Player API error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        message: "Failed to generate streaming URL",
      },
      { status: 500 },
    )
  }
}
