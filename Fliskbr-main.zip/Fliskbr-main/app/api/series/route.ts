import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

const XTREAM_CONFIG = {
  USERNAME: "98413537",
  PASSWORD: "65704277",
  BASE_URL: "https://finstv.wtf/player_api.php",
}

// Mock series data
const MOCK_SERIES = [
  {
    series_id: "1001",
    name: "Breaking Bad",
    cover: "https://image.tmdb.org/t/p/w500/ggFHVNu6YYI5L9pCfOacjizRGt.jpg",
  },
  {
    series_id: "1002",
    name: "Game of Thrones",
    cover: "https://image.tmdb.org/t/p/w500/u3bZgnGQ9T01sWNhyveQz0wH0Hl.jpg",
  },
  {
    series_id: "1003",
    name: "Stranger Things",
    cover: "https://image.tmdb.org/t/p/w500/49WJfeN0moxb9IPfGn8AIqMGskD.jpg",
  },
  {
    series_id: "1004",
    name: "The Office",
    cover: "https://image.tmdb.org/t/p/w500/7DJKHzAi83BmQrWLrYYOqcoKfhR.jpg",
  },
  {
    series_id: "1005",
    name: "Friends",
    cover: "https://image.tmdb.org/t/p/w500/f496cm9enuEsZkSPzCwnTESEK5s.jpg",
  },
]

async function validateApiToken(token: string) {
  try {
    const { data: user, error } = await supabase.from("users").select("*").eq("api_token", token).single()
    if (error || !user) return null

    await supabase.rpc("check_and_reset_user_requests", { user_id: user.id })
    const { data: updatedUser } = await supabase.from("users").select("*").eq("id", user.id).single()
    return updatedUser || user
  } catch (error) {
    return null
  }
}

async function fetchSeriesFromXtream(): Promise<any[]> {
  try {
    const url = `${XTREAM_CONFIG.BASE_URL}?username=${XTREAM_CONFIG.USERNAME}&password=${XTREAM_CONFIG.PASSWORD}&action=get_series`

    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 8000)

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Accept: "application/json",
      },
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`)
    }

    const data = await response.json()
    return Array.isArray(data) ? data : data.results || data.data || []
  } catch (error) {
    console.error("Xtream series API error:", error)
    throw error
  }
}

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "API token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const user = await validateApiToken(token)

    if (!user) {
      return NextResponse.json({ error: "Invalid API token" }, { status: 401 })
    }

    const dailyLimit = user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999
    if (user.daily_requests_used >= dailyLimit) {
      return NextResponse.json(
        {
          error: "Daily request limit exceeded",
          message: `Your ${user.plan} plan allows ${dailyLimit} requests per day`,
        },
        { status: 429 },
      )
    }

    const dominio = request.nextUrl.origin
    let series = []
    let dataSource = "mock"

    // Try Xtream API first
    try {
      const xtreamData = await fetchSeriesFromXtream()

      if (xtreamData && xtreamData.length > 0) {
        series = xtreamData.slice(0, 30).map((item: any) => ({
          id: item.series_id || item.id,
          titulo: item.name || item.title,
          temporadas: `${dominio}/api/series/${item.series_id || item.id}/temporadas`,
          capa: item.cover || item.poster || "https://via.placeholder.com/500x750?text=No+Image",
        }))
        dataSource = "xtream"
      }
    } catch (error) {
      console.log("Xtream series API failed, using mock data")
    }

    // Use mock data if needed
    if (series.length === 0) {
      series = MOCK_SERIES.map((item) => ({
        id: item.series_id,
        titulo: item.name,
        temporadas: `${dominio}/api/series/${item.series_id}/temporadas`,
        capa: item.cover,
      }))
    }

    await supabase
      .from("users")
      .update({ daily_requests_used: user.daily_requests_used + 1 })
      .eq("id", user.id)

    return NextResponse.json({
      success: true,
      data: series,
      meta: {
        dataSource,
        total: series.length,
        page: 1,
        per_page: series.length,
      },
      user_info: {
        requests_used_today: user.daily_requests_used + 1,
        daily_limit: dailyLimit,
        plan: user.plan,
      },
    })
  } catch (error) {
    console.error("Series API error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        message: error.message || "Failed to fetch TV series",
      },
      { status: 500 },
    )
  }
}
