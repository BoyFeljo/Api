import { type NextRequest, NextResponse } from "next/server"

const XTREAM_CONFIG = {
  USERNAME: "98413537",
  PASSWORD: "65704277",
  BASE_URL: "https://finstv.wtf/player_api.php",
}

export async function GET(request: NextRequest) {
  try {
    // Test basic connection
    const testUrl = `${XTREAM_CONFIG.BASE_URL}?username=${XTREAM_CONFIG.USERNAME}&password=${XTREAM_CONFIG.PASSWORD}&action=get_vod_streams`

    console.log("Testing URL:", testUrl)

    const response = await fetch(testUrl, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        Accept: "application/json",
      },
    })

    console.log("Response status:", response.status)
    console.log("Response headers:", Object.fromEntries(response.headers.entries()))

    if (!response.ok) {
      return NextResponse.json(
        {
          error: "HTTP Error",
          status: response.status,
          statusText: response.statusText,
          url: testUrl,
        },
        { status: 500 },
      )
    }

    const data = await response.json()

    return NextResponse.json({
      success: true,
      status: response.status,
      dataType: typeof data,
      isArray: Array.isArray(data),
      dataLength: Array.isArray(data) ? data.length : "Not an array",
      sampleData: Array.isArray(data) ? data.slice(0, 2) : data,
      url: testUrl,
    })
  } catch (error) {
    console.error("Test error:", error)
    return NextResponse.json(
      {
        error: "Connection failed",
        message: error.message,
        stack: error.stack,
      },
      { status: 500 },
    )
  }
}
