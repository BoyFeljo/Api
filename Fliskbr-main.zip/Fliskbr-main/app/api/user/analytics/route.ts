import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Authorization token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    // Get real analytics data
    const { data: analytics, error } = await supabase.rpc("get_user_analytics", {
      p_user_id: decoded.userId,
    })

    if (error) {
      console.error("Analytics error:", error)
      return NextResponse.json({ error: "Failed to fetch analytics" }, { status: 500 })
    }

    const analyticsData = analytics[0] || {
      total_requests_today: 0,
      total_requests_week: 0,
      total_requests_month: 0,
      avg_response_time: 0,
      most_used_endpoint: "/api/filmes",
      success_rate: 100,
      requests_by_day: [],
    }

    // Get user info
    const { data: user } = await supabase.from("users").select("*").eq("id", decoded.userId).single()

    return NextResponse.json({
      success: true,
      data: {
        requests_today: analyticsData.total_requests_today,
        requests_week: analyticsData.total_requests_week,
        requests_month: analyticsData.total_requests_month,
        avg_response_time: Math.round(analyticsData.avg_response_time || 0),
        most_used_endpoint: analyticsData.most_used_endpoint,
        success_rate: Math.round(analyticsData.success_rate || 100),
        uptime: 99.9,
        requests_by_day: analyticsData.requests_by_day || [],
        user_info: {
          plan: user?.plan || "free",
          daily_limit: user?.plan === "free" ? 1000 : user?.plan === "pro" ? 100000 : 999999999,
          rate_limit: user?.rate_limit || 10,
          member_since: user?.created_at,
          total_requests: user?.total_requests || 0,
          last_request: user?.last_request_at,
        },
      },
    })
  } catch (error) {
    console.error("Analytics API error:", error)
    return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  }
}
