import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Authorization token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    // Check and reset daily requests if needed
    await supabase.rpc("check_and_reset_user_requests", { user_id: decoded.userId })

    // Get user data
    const { data: user, error } = await supabase.from("users").select("*").eq("id", decoded.userId).single()

    if (error || !user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json({
      id: user.id,
      name: user.name,
      email: user.email,
      plan: user.plan,
      token: user.api_token,
      daily_requests_used: user.daily_requests_used || 0,
      requests_limit: user.requests_limit || (user.plan === "free" ? 1000 : user.plan === "pro" ? 100000 : 999999999),
      rate_limit: user.rate_limit,
      last_reset_date: user.last_reset_date,
      created_at: user.created_at,
    })
  } catch (error) {
    console.error("Profile error:", error)
    return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  }
}
