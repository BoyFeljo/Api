import { type NextRequest, NextResponse } from "next/server"
import jwt from "jsonwebtoken"
import { createClient } from "@supabase/supabase-js"

const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)

export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get("authorization")
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Authorization token required" }, { status: 401 })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, process.env.JWT_SECRET!) as any

    // Generate new API token
    const newApiToken = jwt.sign({ userId: decoded.userId, timestamp: Date.now() }, process.env.JWT_SECRET!, {
      expiresIn: "1y",
    })

    // Update user's API token
    const { error } = await supabase.from("users").update({ api_token: newApiToken }).eq("id", decoded.userId)

    if (error) {
      return NextResponse.json({ error: "Failed to regenerate token" }, { status: 500 })
    }

    return NextResponse.json({ token: newApiToken })
  } catch (error) {
    console.error("Token regeneration error:", error)
    return NextResponse.json({ error: "Invalid token" }, { status: 401 })
  }
}
