"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Code,
  Copy,
  Eye,
  EyeOff,
  Key,
  LogOut,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Activity,
  Calendar,
  Zap,
  Shield,
  Star,
  TrendingUp,
  BarChart3,
  Clock,
  Target,
  Gift,
  Sparkles,
} from "lucide-react"
import { useRouter } from "next/navigation"
import Link from "next/link"

interface UserData {
  id: string
  name: string
  email: string
  plan: string
  token: string
  daily_requests_used: number
  requests_limit: number
  rate_limit: number
  last_reset_date: string
  created_at: string
}

interface AnalyticsData {
  requests_today: number
  requests_week: number
  requests_month: number
  avg_response_time: number
  most_used_endpoint: string
  success_rate: number
  uptime: number
  requests_by_day: Array<{ date: string; requests: number }>
  user_info: {
    plan: string
    daily_limit: number
    rate_limit: number
    member_since: string
    total_requests: number
    last_request: string
  }
}

export default function DashboardPage() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [showToken, setShowToken] = useState(false)
  const [copied, setCopied] = useState(false)
  const [rewardLink, setRewardLink] = useState<string>("")
  const [generatingLink, setGeneratingLink] = useState(false)
  const [linkMessage, setLinkMessage] = useState("")
  const router = useRouter()

  useEffect(() => {
    const token = localStorage.getItem("token")
    if (!token) {
      router.push("/login")
      return
    }

    fetchUserData(token)
    fetchAnalytics(token)
  }, [router])

  const fetchUserData = async (token: string) => {
    try {
      const response = await fetch("/api/user/profile", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setUserData(data)
      } else {
        localStorage.removeItem("token")
        router.push("/login")
      }
    } catch (error) {
      console.error("Error fetching user data:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchAnalytics = async (token: string) => {
    try {
      const response = await fetch("/api/user/analytics", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const result = await response.json()
        setAnalyticsData(result.data)
      }
    } catch (error) {
      console.error("Error fetching analytics:", error)
    }
  }

  const copyToken = () => {
    if (userData?.token) {
      navigator.clipboard.writeText(userData.token)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const regenerateToken = async () => {
    const token = localStorage.getItem("token")
    if (!token) return

    try {
      const response = await fetch("/api/user/regenerate-token", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setUserData((prev) => (prev ? { ...prev, token: data.token } : null))
      }
    } catch (error) {
      console.error("Error regenerating token:", error)
    }
  }

  const logout = () => {
    localStorage.removeItem("token")
    router.push("/")
  }

  const generateRewardLink = async () => {
    const token = localStorage.getItem("token")
    if (!token) return

    setGeneratingLink(true)
    setLinkMessage("")

    try {
      const response = await fetch("/api/generate-reward-link", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      const data = await response.json()

      if (response.ok) {
        setRewardLink(data.shortenedUrl)
        setLinkMessage(data.message)
      } else {
        setLinkMessage(data.error || "Failed to generate reward link")
      }
    } catch (error) {
      setLinkMessage("Network error. Please try again.")
    } finally {
      setGeneratingLink(false)
    }
  }

  const copyRewardLink = () => {
    if (rewardLink) {
      navigator.clipboard.writeText(rewardLink)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-6"></div>
          <p className="text-gray-300 text-lg">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!userData) {
    return null
  }

  const dailyLimit =
    userData.requests_limit || (userData.plan === "free" ? 1000 : userData.plan === "pro" ? 100000 : 999999999)
  const usagePercentage = (userData.daily_requests_used / dailyLimit) * 100
  const isToday = new Date(userData.last_reset_date).toDateString() === new Date().toDateString()

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-500/5 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Header */}
      <header className="relative border-b border-green-900/20 bg-black/50 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/25">
                <Code className="w-6 h-6 text-black" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
            </div>
            <span className="text-3xl font-bold bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">
              flisk
            </span>
          </Link>
          <div className="flex items-center space-x-4">
            <div className="text-right hidden sm:block">
              <p className="text-gray-300">Welcome back,</p>
              <p className="text-green-400 font-semibold">{userData.name}</p>
            </div>
            <Button
              onClick={logout}
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-red-400 transition-all duration-300"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="relative container mx-auto px-4 py-8 max-w-7xl">
        {/* Overview Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-500/20 to-green-400/10 border-green-500/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs lg:text-sm font-medium text-gray-300 flex items-center">
                <Star className="w-4 h-4 mr-2 text-green-400" />
                Current Plan
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className="bg-gradient-to-r from-green-500/20 to-green-400/20 text-green-400 border-green-500/30 text-sm lg:text-lg px-2 lg:px-3 py-1">
                  {userData.plan.toUpperCase()}
                </Badge>
                <CheckCircle className="w-5 lg:w-6 h-5 lg:h-6 text-green-400" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500/20 to-green-500/10 border-green-500/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs lg:text-sm font-medium text-gray-300 flex items-center">
                <Calendar className="w-4 h-4 mr-2 text-blue-400" />
                Daily Requests
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl lg:text-3xl font-bold text-white mb-2">
                {userData.daily_requests_used.toLocaleString()}
              </div>
              <Progress value={usagePercentage} className="h-2 lg:h-3 mb-2" />
              <p className="text-xs text-gray-400">of {dailyLimit.toLocaleString()} today</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500/20 to-green-500/10 border-green-500/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs lg:text-sm font-medium text-gray-300 flex items-center">
                <Zap className="w-4 h-4 mr-2 text-purple-400" />
                Rate Limit
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl lg:text-3xl font-bold text-white mb-2">{userData.rate_limit}/min</div>
              <div className="flex items-center text-green-400 text-sm">
                <Activity className="w-4 h-4 mr-1" />
                Active
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-500/20 to-green-500/10 border-green-500/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs lg:text-sm font-medium text-gray-300 flex items-center">
                <Shield className="w-4 h-4 mr-2 text-emerald-400" />
                Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-400 font-semibold text-sm lg:text-lg">Active</span>
              </div>
              <p className="text-xs text-gray-400">{isToday ? "Resets tomorrow" : "Reset today"}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500/20 to-green-500/10 border-green-500/30 backdrop-blur-sm hover:scale-105 transition-all duration-300">
            <CardHeader className="pb-3">
              <CardTitle className="text-xs lg:text-sm font-medium text-gray-300 flex items-center">
                <Gift className="w-4 h-4 mr-2 text-yellow-400" />
                Daily Limit
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl lg:text-3xl font-bold text-white mb-2">
                {userData.requests_limit?.toLocaleString() || dailyLimit.toLocaleString()}
              </div>
              <div className="flex items-center text-yellow-400 text-sm">
                <Zap className="w-4 h-4 mr-1" />
                Requests/day
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="token" className="space-y-6">
          <TabsList className="bg-gray-900/50 border-green-500/20 backdrop-blur-sm w-full lg:w-auto">
            <TabsTrigger
              value="token"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500/20 data-[state=active]:to-green-400/20 data-[state=active]:text-green-400 transition-all duration-300 text-xs lg:text-sm"
            >
              <Key className="w-4 h-4 mr-2" />
              API Token
            </TabsTrigger>
            <TabsTrigger
              value="usage"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500/20 data-[state=active]:to-green-400/20 data-[state=active]:text-green-400 transition-all duration-300 text-xs lg:text-sm"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger
              value="docs"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500/20 data-[state=active]:to-green-400/20 data-[state=active]:text-green-400 transition-all duration-300 text-xs lg:text-sm"
            >
              <Code className="w-4 h-4 mr-2" />
              Docs
            </TabsTrigger>
            <TabsTrigger
              value="rewards"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500/20 data-[state=active]:to-green-400/20 data-[state=active]:text-green-400 transition-all duration-300 text-xs lg:text-sm"
            >
              <Gift className="w-4 h-4 mr-2" />
              Rewards
            </TabsTrigger>
          </TabsList>

          <TabsContent value="token">
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-green-500/30 backdrop-blur-xl shadow-2xl shadow-green-500/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center text-xl lg:text-2xl">
                  <Key className="w-5 lg:w-6 h-5 lg:h-6 mr-3 text-green-400" />
                  Your API Token
                </CardTitle>
                <CardDescription className="text-gray-300 text-sm lg:text-lg">
                  Use this token to authenticate your API requests. Keep it secure and don't share it publicly.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col lg:flex-row items-stretch lg:items-center space-y-3 lg:space-y-0 lg:space-x-3">
                  <div className="flex-1 bg-gradient-to-r from-gray-800 to-gray-900 border border-green-500/20 rounded-lg p-3 lg:p-4 font-mono text-xs lg:text-sm backdrop-blur-sm overflow-hidden">
                    <div className="break-all">{showToken ? userData.token : "•".repeat(50)}</div>
                  </div>
                  <div className="flex space-x-2 lg:space-x-3">
                    <Button
                      onClick={() => setShowToken(!showToken)}
                      variant="outline"
                      size="sm"
                      className="border-green-500/30 text-green-400 hover:text-white hover:bg-green-500/10 transition-all duration-300"
                    >
                      {showToken ? (
                        <EyeOff className="w-4 lg:w-5 h-4 lg:h-5" />
                      ) : (
                        <Eye className="w-4 lg:w-5 h-4 lg:h-5" />
                      )}
                    </Button>
                    <Button
                      onClick={copyToken}
                      variant="outline"
                      size="sm"
                      className="border-green-500/30 text-green-400 hover:text-white hover:bg-green-500/10 bg-transparent transition-all duration-300"
                    >
                      {copied ? (
                        <CheckCircle className="w-4 lg:w-5 h-4 lg:h-5" />
                      ) : (
                        <Copy className="w-4 lg:w-5 h-4 lg:h-5" />
                      )}
                    </Button>
                  </div>
                </div>

                <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between pt-6 border-t border-green-500/20 space-y-4 lg:space-y-0">
                  <div className="flex items-center space-x-3 text-yellow-400">
                    <AlertTriangle className="w-5 h-5" />
                    <span className="text-sm font-medium">Keep your token secure</span>
                  </div>
                  <Button
                    onClick={regenerateToken}
                    variant="outline"
                    size="sm"
                    className="border-red-500/30 text-red-400 hover:bg-red-500/10 bg-transparent transition-all duration-300"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="usage">
            <div className="grid gap-6">
              <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-green-500/30 backdrop-blur-xl shadow-2xl shadow-green-500/10">
                <CardHeader>
                  <CardTitle className="text-white text-xl lg:text-2xl">Real-Time Analytics</CardTitle>
                  <CardDescription className="text-gray-300 text-sm lg:text-lg">
                    Monitor your API usage and performance metrics
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    <div>
                      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-4 space-y-2 lg:space-y-0">
                        <span className="text-gray-300 text-lg">Daily Requests</span>
                        <span className="text-white font-bold text-xl">
                          {userData.daily_requests_used.toLocaleString()} / {dailyLimit.toLocaleString()}
                        </span>
                      </div>
                      <Progress value={usagePercentage} className="h-4 mb-3" />
                      <p className="text-sm text-gray-400">
                        {(100 - usagePercentage).toFixed(1)}% remaining • Resets daily at midnight
                      </p>
                    </div>

                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                      <div className="bg-gradient-to-br from-green-500/20 to-green-400/10 rounded-xl p-4 lg:p-6 border border-green-500/20">
                        <div className="text-2xl lg:text-3xl font-bold text-green-400 mb-2">
                          {analyticsData?.requests_today || 0}
                        </div>
                        <div className="text-xs lg:text-sm text-gray-300 flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          Today
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-blue-500/20 to-blue-400/10 rounded-xl p-4 lg:p-6 border border-blue-500/20">
                        <div className="text-2xl lg:text-3xl font-bold text-blue-400 mb-2">
                          {analyticsData?.requests_week || 0}
                        </div>
                        <div className="text-xs lg:text-sm text-gray-300 flex items-center">
                          <BarChart3 className="w-4 h-4 mr-1" />
                          This Week
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-purple-500/20 to-purple-400/10 rounded-xl p-4 lg:p-6 border border-purple-500/20">
                        <div className="text-2xl lg:text-3xl font-bold text-purple-400 mb-2">
                          {analyticsData?.avg_response_time || 0}ms
                        </div>
                        <div className="text-xs lg:text-sm text-gray-300 flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          Avg Response
                        </div>
                      </div>
                      <div className="bg-gradient-to-br from-emerald-500/20 to-emerald-400/10 rounded-xl p-4 lg:p-6 border border-emerald-500/20">
                        <div className="text-2xl lg:text-3xl font-bold text-emerald-400 mb-2">
                          {analyticsData?.success_rate || 100}%
                        </div>
                        <div className="text-xs lg:text-sm text-gray-300 flex items-center">
                          <Target className="w-4 h-4 mr-1" />
                          Success Rate
                        </div>
                      </div>
                    </div>

                    {analyticsData?.most_used_endpoint && (
                      <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 rounded-lg p-4 lg:p-6 border border-green-500/10">
                        <h3 className="text-lg font-semibold text-white mb-2">Most Used Endpoint</h3>
                        <code className="text-green-400 bg-black/30 px-3 py-1 rounded text-sm">
                          {analyticsData.most_used_endpoint}
                        </code>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="docs">
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-green-500/30 backdrop-blur-xl shadow-2xl shadow-green-500/10">
              <CardHeader>
                <CardTitle className="text-white text-xl lg:text-2xl">API Documentation</CardTitle>
                <CardDescription className="text-gray-300 text-sm lg:text-lg">
                  Learn how to integrate with the Flisk API
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-8">
                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Authentication</h3>
                  <p className="text-gray-300">Include your API token in the Authorization header:</p>
                  <pre className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg p-4 lg:p-6 text-sm text-gray-300 overflow-x-auto border border-green-500/20">
                    {`Authorization: Bearer ${userData.token.substring(0, 20)}...`}
                  </pre>
                </div>

                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Available Endpoints</h3>
                  <div className="space-y-4">
                    {[
                      {
                        method: "GET",
                        endpoint: "/api/filmes?limit=100&page=1",
                        description: "Get movies with pagination",
                      },
                      { method: "GET", endpoint: "/api/filmes/categorias", description: "Get movie categories" },
                      { method: "GET", endpoint: "/api/series", description: "Get all TV series" },
                      { method: "GET", endpoint: "/api/series/categorias", description: "Get series categories" },
                      {
                        method: "GET",
                        endpoint: "/api/detalhes",
                        description: "Get detailed information about content",
                      },
                      {
                        method: "GET",
                        endpoint: "/api/player/{slug}.mp4",
                        description: "Get streaming URL for content",
                      },
                    ].map((endpoint, index) => (
                      <div
                        key={index}
                        className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 rounded-lg p-4 border border-green-500/10"
                      >
                        <div className="flex flex-col lg:flex-row items-start lg:items-center space-y-2 lg:space-y-0 lg:space-x-3 mb-2">
                          <Badge className="bg-gradient-to-r from-green-500/20 to-green-400/20 text-green-400 border-green-500/30">
                            {endpoint.method}
                          </Badge>
                          <code className="text-gray-300 font-mono text-sm break-all">{endpoint.endpoint}</code>
                        </div>
                        <p className="text-sm text-gray-400">{endpoint.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Example Request</h3>
                  <pre className="bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg p-4 lg:p-6 text-sm text-gray-300 overflow-x-auto border border-green-500/20">
                    {`curl -X GET "https://api.flisk.dev/api/filmes?limit=50&page=1" \\
  -H "Authorization: Bearer ${userData.token.substring(0, 20)}..." \\
  -H "Content-Type: application/json"

// Response
{
  "success": true,
  "data": [...],
  "meta": {
    "total": 1000,
    "page": 1,
    "per_page": 50,
    "total_pages": 20,
    "has_next": true,
    "response_time_ms": 245
  }
}`}
                  </pre>
                </div>

                <div className="space-y-6">
                  <h3 className="text-lg font-semibold text-white">Rate Limiting</h3>
                  <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 rounded-lg p-4 lg:p-6 border border-yellow-500/20">
                    <div className="flex items-center space-x-3 mb-3">
                      <AlertTriangle className="w-5 h-5 text-yellow-400" />
                      <span className="text-yellow-400 font-semibold">Important</span>
                    </div>
                    <ul className="text-gray-300 space-y-2 text-sm lg:text-base">
                      <li>
                        • Your plan allows <strong>{userData.rate_limit} requests per minute</strong>
                      </li>
                      <li>
                        • Daily limit: <strong>{dailyLimit.toLocaleString()} requests</strong>
                      </li>
                      <li>• Requests reset daily at midnight UTC</li>
                      <li>• Use pagination with limit parameter (max 500 per request)</li>
                      <li>• Exceeding limits will return HTTP 429 status</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          <TabsContent value="rewards">
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-green-500/30 backdrop-blur-xl shadow-2xl shadow-green-500/10">
              <CardHeader>
                <CardTitle className="text-white flex items-center text-xl lg:text-2xl">
                  <Gift className="w-5 lg:w-6 h-5 lg:h-6 mr-3 text-yellow-400" />
                  Earn Extra Requests
                </CardTitle>
                <CardDescription className="text-gray-300 text-sm lg:text-lg">
                  Generate monetized links to earn bonus API requests. Share them to boost your daily limit!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-gradient-to-r from-yellow-500/10 to-green-500/10 rounded-lg p-4 lg:p-6 border border-yellow-500/20">
                  <div className="flex items-center space-x-3 mb-4">
                    <Sparkles className="w-6 h-6 text-yellow-400" />
                    <h3 className="text-lg font-semibold text-white">How it works</h3>
                  </div>
                  <ul className="text-gray-300 space-y-2 text-sm lg:text-base">
                    <li>• Generate a monetized reward link (1 per day)</li>
                    <li>• Share the link with friends or on social media</li>
                    <li>• When someone clicks and completes the reward, you get +250 requests</li>
                    <li>• Bonus requests are added to your daily limit permanently</li>
                  </ul>
                </div>

                <div className="space-y-4">
                  <Button
                    onClick={generateRewardLink}
                    disabled={generatingLink}
                    className="w-full bg-gradient-to-r from-yellow-500 to-green-500 hover:from-yellow-600 hover:to-green-600 text-black font-bold py-3 text-lg shadow-lg shadow-yellow-500/25 transition-all duration-300 hover:scale-105"
                  >
                    {generatingLink ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        <span>Generating...</span>
                      </div>
                    ) : (
                      <div className="flex items-center space-x-2">
                        <Gift className="w-5 h-5" />
                        <span>Generate Reward Link</span>
                      </div>
                    )}
                  </Button>

                  {linkMessage && (
                    <div
                      className={`text-center p-3 rounded-lg ${linkMessage.includes("error") || linkMessage.includes("Failed") ? "bg-red-500/10 border border-red-500/20 text-red-400" : "bg-green-500/10 border border-green-500/20 text-green-400"}`}
                    >
                      {linkMessage}
                    </div>
                  )}

                  {rewardLink && (
                    <div className="space-y-3">
                      <div className="flex flex-col lg:flex-row items-stretch lg:items-center space-y-3 lg:space-y-0 lg:space-x-3">
                        <div className="flex-1 bg-gradient-to-r from-gray-800 to-gray-900 border border-green-500/20 rounded-lg p-3 lg:p-4 font-mono text-xs lg:text-sm backdrop-blur-sm overflow-hidden">
                          <div className="break-all">{rewardLink}</div>
                        </div>
                        <Button
                          onClick={copyRewardLink}
                          variant="outline"
                          size="sm"
                          className="border-green-500/30 text-green-400 hover:text-white hover:bg-green-500/10 bg-transparent transition-all duration-300"
                        >
                          {copied ? (
                            <CheckCircle className="w-4 lg:w-5 h-4 lg:h-5" />
                          ) : (
                            <Copy className="w-4 lg:w-5 h-4 lg:h-5" />
                          )}
                        </Button>
                      </div>
                      <p className="text-sm text-gray-400 text-center">
                        💡 Share this link to earn +250 API requests when someone completes the reward!
                      </p>
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 rounded-lg p-4 lg:p-6 border border-green-500/20">
                  <h3 className="text-lg font-semibold text-white mb-3 flex items-center">
                    <Star className="w-5 h-5 mr-2 text-green-400" />
                    Current Stats
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="text-2xl font-bold text-green-400">
                        {userData.requests_limit?.toLocaleString() || dailyLimit.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-400">Daily Limit</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-blue-400">
                        {userData.daily_requests_used.toLocaleString()}
                      </div>
                      <div className="text-sm text-gray-400">Used Today</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
