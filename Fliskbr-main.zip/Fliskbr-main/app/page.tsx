import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Code, Shield, Zap, Users, ArrowRight, Play, Database, Globe, Star, Sparkles } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white overflow-hidden">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      {/* Header */}
      <header className="relative border-b border-green-900/20 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/25">
                <Code className="w-6 h-6 text-black" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full animate-ping"></div>
            </div>
            <span className="text-3xl font-bold bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">
              flisk
            </span>
          </div>
          <nav className="hidden md:flex items-center space-x-8">
            <Link
              href="#features"
              className="text-gray-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
            >
              Features
            </Link>
            <Link
              href="#pricing"
              className="text-gray-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
            >
              Pricing
            </Link>
            <Link
              href="#docs"
              className="text-gray-300 hover:text-green-400 transition-all duration-300 hover:scale-105"
            >
              Docs
            </Link>
          </nav>
          <div className="flex items-center space-x-3">
            <Link href="/login">
              <Button
                variant="ghost"
                className="text-gray-300 hover:text-green-400 hover:bg-green-500/10 transition-all duration-300"
              >
                Login
              </Button>
            </Link>
            <Link href="/register">
              <Button className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-semibold shadow-lg shadow-green-500/25 transition-all duration-300 hover:scale-105">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-32 px-4">
        <div className="container mx-auto text-center">
          <div className="relative inline-block mb-8">
            <Badge className="mb-6 bg-gradient-to-r from-green-500/20 to-green-400/20 text-green-400 border-green-500/30 backdrop-blur-sm">
              <Sparkles className="w-4 h-4 mr-2" />🚀 Now Available
            </Badge>
          </div>

          <h1 className="text-6xl md:text-8xl font-bold mb-8 leading-tight">
            <span className="bg-gradient-to-r from-white via-green-100 to-green-400 bg-clip-text text-transparent">
              Streaming API
            </span>
            <br />
            <span className="bg-gradient-to-r from-green-400 via-green-300 to-green-500 bg-clip-text text-transparent animate-pulse">
              Made Simple
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
            Access thousands of movies and TV shows through our powerful API. Get your token and start building amazing
            streaming applications today with{" "}
            <span className="text-green-400 font-semibold">unlimited possibilities</span>.
          </p>

          <div className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link href="/register">
              <Button
                size="lg"
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-bold px-8 py-4 text-lg shadow-2xl shadow-green-500/25 transition-all duration-300 hover:scale-110 hover:shadow-green-500/40"
              >
                Start Free Trial
                <ArrowRight className="ml-3 w-5 h-5" />
              </Button>
            </Link>
            <Link href="#demo">
              <Button
                size="lg"
                variant="outline"
                className="border-green-500/30 text-green-400 hover:bg-green-500/10 bg-black/20 backdrop-blur-sm px-8 py-4 text-lg transition-all duration-300 hover:scale-105 hover:border-green-400"
              >
                <Play className="mr-3 w-5 h-5" />
                View Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="relative py-32 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
              Everything you need to build
            </h2>
            <p className="text-gray-300 text-xl max-w-3xl mx-auto leading-relaxed">
              Our API provides comprehensive access to streaming content with enterprise-grade security and reliability.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Database,
                title: "Vast Content Library",
                description: "Access thousands of movies and TV series with detailed metadata",
                features: ["Movies and TV Shows", "Multiple categories", "HD streaming links", "TMDB integration"],
                gradient: "from-blue-500/20 to-green-500/20",
              },
              {
                icon: Shield,
                title: "Secure Authentication",
                description: "Token-based authentication with rate limiting protection",
                features: ["Unique API tokens", "Daily rate reset", "Usage analytics", "Secure endpoints"],
                gradient: "from-green-500/20 to-emerald-500/20",
              },
              {
                icon: Zap,
                title: "Lightning Fast",
                description: "Optimized endpoints with global CDN for maximum performance",
                features: ["Global CDN", "99.9% uptime", "Fast response times", "Cached results"],
                gradient: "from-yellow-500/20 to-green-500/20",
              },
              {
                icon: Globe,
                title: "RESTful API",
                description: "Clean, intuitive REST API with comprehensive documentation",
                features: ["RESTful design", "JSON responses", "Clear documentation", "Code examples"],
                gradient: "from-purple-500/20 to-green-500/20",
              },
              {
                icon: Users,
                title: "Developer Friendly",
                description: "Built by developers, for developers with great DX in mind",
                features: ["Easy integration", "Multiple SDKs", "Active community", "24/7 support"],
                gradient: "from-pink-500/20 to-green-500/20",
              },
              {
                icon: Code,
                title: "Rich Metadata",
                description: "Detailed information about every movie and TV show",
                features: ["Cast & crew info", "Ratings & reviews", "Posters & backdrops", "Trailers & videos"],
                gradient: "from-indigo-500/20 to-green-500/20",
              },
            ].map((feature, index) => (
              <Card
                key={index}
                className={`bg-gradient-to-br ${feature.gradient} border-green-500/20 hover:border-green-500/40 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-green-500/10 backdrop-blur-sm group`}
              >
                <CardHeader>
                  <div className="relative">
                    <feature.icon className="w-12 h-12 text-green-400 mb-4 group-hover:scale-110 transition-transform duration-300" />
                    <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-400/20 rounded-full animate-ping group-hover:animate-pulse"></div>
                  </div>
                  <CardTitle className="text-white text-xl group-hover:text-green-100 transition-colors duration-300">
                    {feature.title}
                  </CardTitle>
                  <CardDescription className="text-gray-300 group-hover:text-gray-200 transition-colors duration-300">
                    {feature.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="text-sm text-gray-300 space-y-3">
                    {feature.features.map((item, i) => (
                      <li
                        key={i}
                        className="flex items-center group-hover:text-gray-200 transition-colors duration-300"
                      >
                        <Star className="w-4 h-4 text-green-400 mr-2 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* API Preview */}
      <section id="demo" className="relative py-32 px-4 bg-gradient-to-r from-black/50 to-gray-900/50 backdrop-blur-sm">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
              Simple to integrate
            </h2>
            <p className="text-gray-300 text-xl">Get started with just a few lines of code</p>
          </div>

          <div className="max-w-5xl mx-auto">
            <Card className="bg-gradient-to-br from-gray-900/80 to-black/80 border-green-500/30 backdrop-blur-xl shadow-2xl shadow-green-500/10">
              <CardHeader>
                <CardTitle className="text-green-400 flex items-center text-xl">
                  <Code className="mr-3 w-6 h-6" />
                  Example Request
                </CardTitle>
              </CardHeader>
              <CardContent>
                <pre className="text-sm text-gray-300 overflow-x-auto bg-black/40 rounded-lg p-6 border border-green-500/20">
                  {`curl -X GET "https://api.flisk.dev/filmes" \\
  -H "Authorization: Bearer YOUR_API_TOKEN" \\
  -H "Content-Type: application/json"

// Response
{
  "data": [
    {
      "id": "12345",
      "titulo": "Inception",
      "ano": "2010",
      "capa": "https://image.tmdb.org/t/p/w500/...",
      "player": "https://api.flisk.dev/player/inception-abc123.mp4",
      "detalhes": "https://api.flisk.dev/detalhes?titulo=Inception&tipo=filme"
    }
  ]
}`}
                </pre>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="relative py-32 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
              Simple, transparent pricing
            </h2>
            <p className="text-gray-300 text-xl">Choose the plan that fits your needs</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              {
                name: "Free",
                description: "Perfect for testing",
                price: "$0",
                features: ["1,000 requests/day", "Basic support", "All endpoints", "Rate limiting: 10/min"],
                popular: false,
              },
              {
                name: "Pro",
                description: "For growing applications",
                price: "$29",
                features: ["100,000 requests/day", "Priority support", "All endpoints", "Rate limiting: 100/min"],
                popular: true,
              },
              {
                name: "Enterprise",
                description: "For large scale applications",
                price: "$99",
                features: ["Unlimited requests", "24/7 dedicated support", "All endpoints", "Custom rate limits"],
                popular: false,
              },
            ].map((plan, index) => (
              <Card
                key={index}
                className={`relative ${plan.popular ? "bg-gradient-to-br from-green-500/20 to-green-400/10 border-green-400 scale-105" : "bg-gradient-to-br from-gray-900/50 to-black/50 border-green-500/20"} backdrop-blur-sm transition-all duration-500 hover:scale-110 hover:shadow-2xl hover:shadow-green-500/20`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-green-500 to-green-400 text-black font-bold px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-white text-2xl">{plan.name}</CardTitle>
                  <CardDescription className="text-gray-300 text-lg">{plan.description}</CardDescription>
                  <div className="text-4xl font-bold text-green-400 mt-6">{plan.price}</div>
                  <div className="text-gray-400">/month</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4 text-gray-300 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center">
                        <Star className="w-5 h-5 text-green-400 mr-3 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  <Link href="/register" className="block">
                    <Button
                      className={`w-full ${plan.popular ? "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black" : "bg-gradient-to-r from-gray-700 to-gray-800 hover:from-gray-600 hover:to-gray-700 text-white"} font-semibold py-3 transition-all duration-300 hover:scale-105`}
                    >
                      {plan.name === "Enterprise" ? "Contact Sales" : "Get Started"}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative border-t border-green-900/20 py-16 px-4 bg-gradient-to-r from-black to-gray-900">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-3 mb-6 md:mb-0">
              <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/25">
                <Code className="w-6 h-6 text-black" />
              </div>
              <span className="text-3xl font-bold bg-gradient-to-r from-green-400 to-green-300 bg-clip-text text-transparent">
                flisk
              </span>
            </div>
            <div className="flex space-x-8 text-gray-300">
              {["Documentation", "Support", "Privacy", "Terms"].map((link) => (
                <Link
                  key={link}
                  href={`/${link.toLowerCase()}`}
                  className="hover:text-green-400 transition-all duration-300 hover:scale-105"
                >
                  {link}
                </Link>
              ))}
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-green-900/20 text-center text-gray-400">
            <p>&copy; 2024 Flisk API. All rights reserved. Built with ❤️ for developers.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
