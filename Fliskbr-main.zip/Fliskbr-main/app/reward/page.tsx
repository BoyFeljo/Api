"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Code, Gift, CheckCircle, AlertTriangle, Sparkles, Star, Zap } from "lucide-react"
import { useSearchParams, useRouter } from "next/navigation"
import Link from "next/link"

export default function RewardPage() {
  const [loading, setLoading] = useState(false)
  const [claimed, setClaimed] = useState(false)
  const [error, setError] = useState("")
  const [rewardAmount, setRewardAmount] = useState(0)
  const searchParams = useSearchParams()
  const router = useRouter()
  const token = searchParams.get("token")

  useEffect(() => {
    if (!token) {
      setError("Invalid reward link")
    }
  }, [token])

  const claimReward = async () => {
    if (!token) return

    setLoading(true)
    setError("")

    try {
      const response = await fetch("/api/claim-reward", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
      })

      const data = await response.json()

      if (response.ok) {
        setClaimed(true)
        setRewardAmount(data.rewardAmount)
      } else {
        setError(data.error || "Failed to claim reward")
      }
    } catch (error) {
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black text-white flex items-center justify-center p-4">
      {/* Animated background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-green-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-green-400/5 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-green-500/5 rounded-full blur-3xl animate-pulse delay-500"></div>
      </div>

      <div className="w-full max-w-md relative">
        {/* Header */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center space-x-2 mb-6">
            <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
              <Code className="w-6 h-6 text-black" />
            </div>
            <span className="text-3xl font-bold text-green-400">flisk</span>
          </Link>
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Gift className="w-8 h-8 text-green-400" />
            <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">🎉 Congratulations!</h1>
          <p className="text-gray-400">You've found a reward link!</p>
        </div>

        <Card className="bg-gray-900/50 border-green-500/20 backdrop-blur-xl shadow-2xl shadow-green-500/10">
          <CardHeader className="text-center">
            <CardTitle className="text-white text-2xl flex items-center justify-center space-x-2">
              <Star className="w-6 h-6 text-yellow-400" />
              <span>Free API Requests</span>
              <Star className="w-6 h-6 text-yellow-400" />
            </CardTitle>
            <CardDescription className="text-gray-400 text-lg">
              Claim your bonus requests to boost your API usage!
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {!claimed && !error && (
              <div className="text-center space-y-6">
                <div className="bg-gradient-to-r from-green-500/20 to-green-400/20 rounded-xl p-6 border border-green-500/30">
                  <div className="flex items-center justify-center space-x-3 mb-4">
                    <Zap className="w-8 h-8 text-green-400" />
                    <span className="text-3xl font-bold text-green-400">+500</span>
                  </div>
                  <p className="text-gray-300">Extra API Requests</p>
                  <p className="text-sm text-gray-400 mt-2">Added to your daily limit</p>
                </div>

                <Button
                  onClick={claimReward}
                  disabled={loading || !token}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-bold py-4 text-lg shadow-lg shadow-green-500/25 transition-all duration-300 hover:scale-105"
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                      <span>Claiming...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Gift className="w-5 h-5" />
                      <span>Claim Reward</span>
                    </div>
                  )}
                </Button>
              </div>
            )}

            {claimed && (
              <div className="text-center space-y-6">
                <div className="bg-gradient-to-r from-green-500/20 to-green-400/20 rounded-xl p-6 border border-green-500/30">
                  <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-green-400 mb-2">Reward Claimed!</h3>
                  <p className="text-gray-300 text-lg">
                    You've received <span className="font-bold text-green-400">+{rewardAmount}</span> extra API
                    requests!
                  </p>
                  <p className="text-sm text-gray-400 mt-2">Check your dashboard to see the updated limit</p>
                </div>

                <div className="space-y-3">
                  <Link href="/dashboard">
                    <Button className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-semibold">
                      Go to Dashboard
                    </Button>
                  </Link>
                  <Link href="/">
                    <Button
                      variant="outline"
                      className="w-full border-green-500/30 text-green-400 hover:bg-green-500/10 bg-transparent"
                    >
                      Back to Home
                    </Button>
                  </Link>
                </div>
              </div>
            )}

            {error && (
              <div className="text-center space-y-6">
                <div className="bg-gradient-to-r from-red-500/20 to-red-400/20 rounded-xl p-6 border border-red-500/30">
                  <AlertTriangle className="w-16 h-16 text-red-400 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-red-400 mb-2">Oops!</h3>
                  <p className="text-gray-300">{error}</p>
                </div>

                <Link href="/">
                  <Button
                    variant="outline"
                    className="w-full border-green-500/30 text-green-400 hover:bg-green-500/10 bg-transparent"
                  >
                    Back to Home
                  </Button>
                </Link>
              </div>
            )}

            <div className="text-center pt-4 border-t border-green-500/20">
              <p className="text-xs text-gray-400">💡 Share reward links with friends to earn more requests!</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
