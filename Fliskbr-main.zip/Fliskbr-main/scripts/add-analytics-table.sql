-- Create analytics table for real usage tracking
CREATE TABLE IF NOT EXISTS user_analytics (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  endpoint VARCHAR(255) NOT NULL,
  method VARCHAR(10) DEFAULT 'GET',
  status_code INTEGER NOT NULL,
  response_time_ms INTEGER,
  request_date DATE DEFAULT CURRENT_DATE,
  request_timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  ip_address INET,
  user_agent TEXT
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_user_analytics_user_id ON user_analytics(user_id);
CREATE INDEX IF NOT EXISTS idx_user_analytics_date ON user_analytics(request_date);
CREATE INDEX IF NOT EXISTS idx_user_analytics_endpoint ON user_analytics(endpoint);

-- Add more fields to users table for analytics
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_requests INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_request_at TIMESTAMP WITH TIME ZONE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS avg_response_time_ms FLOAT DEFAULT 0;

-- Function to log API usage
CREATE OR REPLACE FUNCTION log_api_usage(
  p_user_id UUID,
  p_endpoint VARCHAR(255),
  p_method VARCHAR(10),
  p_status_code INTEGER,
  p_response_time_ms INTEGER,
  p_ip_address INET DEFAULT NULL,
  p_user_agent TEXT DEFAULT NULL
)
RETURNS void AS $$
BEGIN
  -- Insert analytics record
  INSERT INTO user_analytics (
    user_id, endpoint, method, status_code, response_time_ms, ip_address, user_agent
  ) VALUES (
    p_user_id, p_endpoint, p_method, p_status_code, p_response_time_ms, p_ip_address, p_user_agent
  );
  
  -- Update user stats
  UPDATE users 
  SET 
    total_requests = total_requests + 1,
    last_request_at = NOW(),
    avg_response_time_ms = (
      SELECT AVG(response_time_ms) 
      FROM user_analytics 
      WHERE user_id = p_user_id AND response_time_ms IS NOT NULL
    )
  WHERE id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- Function to get user analytics
CREATE OR REPLACE FUNCTION get_user_analytics(p_user_id UUID)
RETURNS TABLE(
  total_requests_today INTEGER,
  total_requests_week INTEGER,
  total_requests_month INTEGER,
  avg_response_time FLOAT,
  most_used_endpoint VARCHAR(255),
  success_rate FLOAT,
  requests_by_day JSON
) AS $$
BEGIN
  RETURN QUERY
  WITH daily_stats AS (
    SELECT 
      request_date,
      COUNT(*) as requests,
      AVG(response_time_ms) as avg_time,
      COUNT(CASE WHEN status_code < 400 THEN 1 END) as success_count
    FROM user_analytics 
    WHERE user_id = p_user_id 
      AND request_date >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY request_date
    ORDER BY request_date DESC
  ),
  endpoint_stats AS (
    SELECT 
      endpoint,
      COUNT(*) as usage_count
    FROM user_analytics 
    WHERE user_id = p_user_id 
      AND request_date >= CURRENT_DATE - INTERVAL '30 days'
    GROUP BY endpoint
    ORDER BY usage_count DESC
    LIMIT 1
  )
  SELECT 
    COALESCE((SELECT COUNT(*) FROM user_analytics WHERE user_id = p_user_id AND request_date = CURRENT_DATE), 0)::INTEGER,
    COALESCE((SELECT COUNT(*) FROM user_analytics WHERE user_id = p_user_id AND request_date >= CURRENT_DATE - INTERVAL '7 days'), 0)::INTEGER,
    COALESCE((SELECT COUNT(*) FROM user_analytics WHERE user_id = p_user_id AND request_date >= CURRENT_DATE - INTERVAL '30 days'), 0)::INTEGER,
    COALESCE((SELECT AVG(avg_time) FROM daily_stats), 0)::FLOAT,
    COALESCE((SELECT endpoint FROM endpoint_stats), '/api/filmes')::VARCHAR(255),
    COALESCE((SELECT (SUM(success_count)::FLOAT / SUM(requests) * 100) FROM daily_stats), 100.0)::FLOAT,
    COALESCE((SELECT json_agg(json_build_object('date', request_date, 'requests', requests)) FROM daily_stats), '[]'::JSON);
END;
$$ LANGUAGE plpgsql;
