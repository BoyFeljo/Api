-- Create reward_links table
CREATE TABLE IF NOT EXISTS reward_links (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  reward_token TEXT UNIQUE NOT NULL,
  shortened_url TEXT NOT NULL,
  destination_url TEXT NOT NULL,
  alias VARCHAR(50) NOT NULL,
  created_date DATE DEFAULT CURRENT_DATE,
  is_claimed BOOLEAN DEFAULT FALSE,
  claimed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_reward_links_user_id ON reward_links(user_id);
CREATE INDEX IF NOT EXISTS idx_reward_links_token ON reward_links(reward_token);
CREATE INDEX IF NOT EXISTS idx_reward_links_date ON reward_links(created_date);
CREATE INDEX IF NOT EXISTS idx_reward_links_claimed ON reward_links(is_claimed);

-- Add constraint to prevent multiple links per user per day
CREATE UNIQUE INDEX IF NOT EXISTS idx_reward_links_user_date 
ON reward_links(user_id, created_date) 
WHERE is_claimed = false;
