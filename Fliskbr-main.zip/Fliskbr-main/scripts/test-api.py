import requests
import json

# Configuração
API_TOKEN = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1veXNlaXNuZXRvMjAyMEBnbWFpbC5jb20iLCJ0aW1lc3RhbXAiOjE3NTM1MDg2MjU0NjIsImlhdCI6MTc1MzUwODYyNSwiZXhwIjoxNzg1MDY2MjI1fQ.HOZOuctzmXEx9fagiSRRWWJeO2YUpv9SGmSBO3aW9iE'
BASE_URL = 'https://v0-python-flask-app-eight.vercel.app/api'

headers = {
    'Authorization': f'Bearer {API_TOKEN}',
    'Content-Type': 'application/json'
}

def test_endpoint(endpoint, description):
    print(f"\n{'='*50}")
    print(f"🧪 TESTANDO: {description}")
    print(f"📍 Endpoint: {endpoint}")
    print(f"{'='*50}")
    
    try:
        response = requests.get(f'{BASE_URL}{endpoint}', headers=headers, timeout=30)
        
        print(f"📊 Status Code: {response.status_code}")
        print(f"⏱️  Response Time: {response.elapsed.total_seconds():.2f}s")
        
        if response.status_code == 200:
            data = response.json()
            print("✅ SUCESSO!")
            
            if 'data' in data:
                print(f"📦 Total de itens: {len(data['data'])}")
                if data['data']:
                    print("🎬 Primeiros itens:")
                    for i, item in enumerate(data['data'][:3]):
                        print(f"   {i+1}. {item.get('titulo', 'N/A')} ({item.get('ano', 'N/A')})")
            
            if 'meta' in data:
                print(f"🔍 Fonte dos dados: {data['meta'].get('dataSource', 'N/A')}")
            
            if 'user_info' in data:
                user_info = data['user_info']
                print(f"👤 Requests hoje: {user_info.get('requests_used_today', 0)}/{user_info.get('daily_limit', 0)}")
                print(f"📋 Plano: {user_info.get('plan', 'N/A')}")
                
        else:
            print("❌ ERRO!")
            try:
                error_data = response.json()
                print(f"💬 Mensagem: {error_data.get('message', 'N/A')}")
                print(f"🔍 Erro: {error_data.get('error', 'N/A')}")
            except:
                print(f"📄 Resposta raw: {response.text[:200]}...")
                
    except requests.exceptions.Timeout:
        print("⏰ TIMEOUT - Requisição demorou mais de 30 segundos")
    except requests.exceptions.ConnectionError:
        print("🌐 ERRO DE CONEXÃO - Não foi possível conectar ao servidor")
    except Exception as e:
        print(f"💥 ERRO INESPERADO: {str(e)}")

def main():
    print("🚀 INICIANDO TESTES DA API FLISK")
    print(f"🔑 Token: {API_TOKEN[:20]}...")
    print(f"🌐 Base URL: {BASE_URL}")
    
    # Lista de testes
    tests = [
        ('/filmes', 'Listar Filmes'),
        ('/series', 'Listar Séries'),
        ('/filmes/categorias', 'Categorias de Filmes'),
        ('/series/categorias', 'Categorias de Séries'),
        ('/detalhes?titulo=Inception&tipo=filme', 'Detalhes do Filme'),
        ('/test-xtream', 'Teste Conectividade Xtream'),
    ]
    
    # Executar testes
    for endpoint, description in tests:
        test_endpoint(endpoint, description)
    
    print(f"\n{'='*50}")
    print("🏁 TESTES CONCLUÍDOS!")
    print(f"{'='*50}")

if __name__ == "__main__":
    main()
