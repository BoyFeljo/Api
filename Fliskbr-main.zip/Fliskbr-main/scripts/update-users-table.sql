-- Add daily reset fields to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_reset_date DATE DEFAULT CURRENT_DATE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS daily_requests_used INTEGER DEFAULT 0;

-- Update existing users to have today's date
UPDATE users SET last_reset_date = CURRENT_DATE WHERE last_reset_date IS NULL;

-- Create function to reset daily requests
CREATE OR REPLACE FUNCTION reset_daily_requests()
RETURNS void AS $$
BEGIN
    UPDATE users 
    SET daily_requests_used = 0, 
        last_reset_date = CURRENT_DATE
    WHERE last_reset_date < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql;

-- Create a function to check and reset if needed for a specific user
CREATE OR REPLACE FUNCTION check_and_reset_user_requests(user_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE users 
    SET daily_requests_used = 0, 
        last_reset_date = CURRENT_DATE
    WHERE id = user_id AND last_reset_date < CURRENT_DATE;
END;
$$ LANGUAGE plpgsql;
